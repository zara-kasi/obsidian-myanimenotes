/**
 * Storage Service - Main entry point
 * 
 * ARCHITECTURE:
 * - cassette-sync-manager.ts: Handles cassette_sync lookup and locking
 * - file-utils.ts: File operations and sanitization
 * - frontmatter-builder.ts: Builds and merges frontmatter
 * - markdown-generator.ts: Generates markdown content
 */

import { Notice } from 'obsidian';
import type CassettePlugin from '../../main';
import type { UniversalMediaItem } from '../types';
import type { PropertyMapping } from './property-mapping';
import { DEFAULT_PROPERTY_MAPPING } from './property-mapping';
import { 
  generateCassetteSync, 
  findFilesByCassetteSync, 
  findLegacyFiles, 
  selectDeterministicFile,
  acquireSyncLock,
  releaseSyncLock
} from './cassette-sync-manager';
import { ensureFolderExists, generateUniqueFilename } from './file-utils';
import { generateMarkdownWithCassetteSync } from './markdown-generator';

/**
 * Storage configuration
 */
export interface StorageConfig {
  animeFolder: string;
  mangaFolder: string;
  createFolders: boolean;
  propertyMapping?: PropertyMapping;
}

/**
 * Sync action result
 */
export interface SyncActionResult {
  action: 'created' | 'updated' | 'linked-legacy' | 'duplicates-detected';
  filePath: string;
  cassetteSync: string;
  duplicatePaths?: string[];
  message?: string;
}

/**
 * Main save function with cassette_sync-based lookup
 * 
 * LOOKUP ORDER:
 * 1. Search by cassette_sync frontmatter (exact match)
 * 2. If multiple found: report duplicates, pick deterministic file
 * 3. If none found: try legacy file detection
 * 4. If still none: create new file with cassette_sync
 */
export async function saveMediaItem(
  plugin: CassettePlugin,
  item: UniversalMediaItem,
  config: StorageConfig
): Promise<SyncActionResult> {
  const { vault } = plugin.app;
  
  // Generate cassette_sync identifier (format: provider:category:id)
  const cassetteSync = generateCassetteSync(item);
  console.log(`[Storage] Processing item with cassette_sync: ${cassetteSync}`);
  
  // Acquire lock to prevent concurrent operations on same ID
  await acquireSyncLock(cassetteSync);
  
  try {
    // Determine target folder
    const folderPath = item.category === 'anime' ? config.animeFolder : config.mangaFolder;
    
    if (config.createFolders) {
      await ensureFolderExists(plugin, folderPath);
    }
    
    // STEP 1: Lookup by cassette_sync frontmatter
    const matchingFiles = await findFilesByCassetteSync(plugin, cassetteSync, folderPath);
    
    if (matchingFiles.length > 1) {
      // DUPLICATE DETECTION: Multiple files with same cassette_sync
      console.warn(`[Storage] Found ${matchingFiles.length} files with cassette_sync: ${cassetteSync}`);
      
      const selectedFile = selectDeterministicFile(matchingFiles);
      const existingContent = await vault.read(selectedFile);
      const content = generateMarkdownWithCassetteSync(item, config, cassetteSync, existingContent);
      
      await vault.modify(selectedFile, content);
      
      return {
        action: 'duplicates-detected',
        filePath: selectedFile.path,
        cassetteSync,
        duplicatePaths: matchingFiles.map(f => f.path),
        message: `Updated ${selectedFile.path} but found ${matchingFiles.length} duplicates`
      };
    }
    
    if (matchingFiles.length === 1) {
      // EXACT MATCH: Update existing file
      const file = matchingFiles[0];
      console.log(`[Storage] Updating existing file: ${file.path}`);
      
      const existingContent = await vault.read(file);
      const content = generateMarkdownWithCassetteSync(item, config, cassetteSync, existingContent);
      
      await vault.modify(file, content);
      
      return {
        action: 'updated',
        filePath: file.path,
        cassetteSync,
        message: `Updated ${file.path}`
      };
    }
    
    // STEP 2: No cassette_sync match - try legacy file detection
    console.log(`[Storage] No cassette_sync match, attempting legacy file detection...`);
    const legacyCandidates = await findLegacyFiles(plugin, item, folderPath);
    
    if (legacyCandidates.length > 0) {
      if (legacyCandidates.length > 1) {
        console.warn(`[Storage] Found ${legacyCandidates.length} legacy candidates for ${cassetteSync}`);
      }
      
      const selectedFile = selectDeterministicFile(legacyCandidates);
      console.log(`[Storage] Migrating legacy file: ${selectedFile.path}`);
      
      const existingContent = await vault.read(selectedFile);
      const content = generateMarkdownWithCassetteSync(item, config, cassetteSync, existingContent);
      
      await vault.modify(selectedFile, content);
      
      return {
        action: 'linked-legacy',
        filePath: selectedFile.path,
        cassetteSync,
        duplicatePaths: legacyCandidates.length > 1 ? legacyCandidates.map(f => f.path) : undefined,
        message: `Migrated legacy file ${selectedFile.path} (added cassette_sync)`
      };
    }
    
    // STEP 3: No existing file - create new file
    console.log(`[Storage] Creating new file for ${cassetteSync}`);
    
    const sanitizedTitle = item.title.replace(/[\\/:*?"<>|]/g, '-').replace(/\s+/g, ' ').trim();
    let filename = `${sanitizedTitle}.md`;
    
    // Check for filename collision and generate unique name if needed
    const existingByName = vault.getAbstractFileByPath(`${folderPath}/${filename}`);
    if (existingByName) {
      console.log(`[Storage] Filename collision detected, generating unique name`);
      filename = generateUniqueFilename(vault, folderPath, filename);
    }
    
    const filePath = `${folderPath}/${filename}`;
    const content = generateMarkdownWithCassetteSync(item, config, cassetteSync);
    
    await vault.create(filePath, content);
    
    return {
      action: 'created',
      filePath,
      cassetteSync,
      message: `Created ${filePath}`
    };
    
  } finally {
    // Always release lock
    releaseSyncLock(cassetteSync);
  }
}

/**
 * Saves multiple media items
 */
export async function saveMediaItems(
  plugin: CassettePlugin,
  items: UniversalMediaItem[],
  config: StorageConfig
): Promise<SyncActionResult[]> {
  const results: SyncActionResult[] = [];
  
  new Notice(`💾 Saving ${items.length} items...`, 2000);
  
  for (const item of items) {
    try {
      const result = await saveMediaItem(plugin, item, config);
      results.push(result);
      
      // Log important events
      if (result.action === 'duplicates-detected') {
        console.warn(`[Storage] ${result.message}`);
        new Notice(`⚠️ Duplicates found: ${item.title}`, 3000);
      } else if (result.action === 'linked-legacy') {
        console.log(`[Storage] ${result.message}`);
      }
    } catch (error) {
      console.error(`[Storage] Failed to save ${item.title}:`, error);
      new Notice(`❌ Failed to save: ${item.title}`, 3000);
    }
  }
  
  new Notice(`✅ Saved ${results.length} items to vault`, 3000);
  
  return results;
}

/**
 * Saves items grouped by category
 */
export async function saveMediaItemsByCategory(
  plugin: CassettePlugin,
  items: UniversalMediaItem[],
  config: StorageConfig
): Promise<{ anime: string[]; manga: string[] }> {
  const animePaths: string[] = [];
  const mangaPaths: string[] = [];
  
  const animeItems = items.filter(item => item.category === 'anime');
  const mangaItems = items.filter(item => item.category === 'manga');
  
  if (animeItems.length > 0) {
    new Notice(`💾 Saving ${animeItems.length} anime items...`, 2000);
    const results = await saveMediaItems(plugin, animeItems, config);
    animePaths.push(...results.map(r => r.filePath));
  }
  
  if (mangaItems.length > 0) {
    new Notice(`💾 Saving ${mangaItems.length} manga items...`, 2000);
    const results = await saveMediaItems(plugin, mangaItems, config);
    mangaPaths.push(...results.map(r => r.filePath));
  }
  
  return { anime: animePaths, manga: mangaPaths };
}